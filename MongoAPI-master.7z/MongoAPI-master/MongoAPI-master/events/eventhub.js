var events = require('events');

var emitter = new events.EventEmitter();

emitter.on("update",function(data){
    logger.info("Number of employees in " + data + " is updated!");
});

emitter.on("more",function(data){
    logger.info("Number of records exceeded than 50 for your search pattern " + data);
});

module.exports=emitter;
